﻿using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Recipes_app
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //declare generics
        public static List<string> recipeName = new List<string>();
        public static List<string> ingredientsNumber = new List<string>();
        public static List<string> ingredientName = new List<string>();
        public static List<string> ingredientQuantity = new List<string>();
        public static List<string> ingredientUnit = new List<string>();
        public static List<string> ingredientCalories = new List<string>();
        public static List<string> ingredientFoodGroup = new List<string>();
        public static List<string> stepsNumber = new List<string>();
        public static List<string> stepDescription = new List<string>();

        public static List<string> firstIngredientQuantity = new List<string>();

        public static List<string> ingredientFilterFoodGroup = new List<string>();

        int ingAccumulate = 1;

        public SeriesCollection SeriesCollection { get; set; } // set and set
        public MainWindow()
        {
            InitializeComponent();
        }
        private void enterRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            captureDetails.Visibility = Visibility.Visible;

            labelIngredientNumber.Visibility = Visibility.Visible;
            ingInput.Visibility = Visibility.Visible;

            labelRecipeName.Visibility = Visibility.Visible;
            recipeInput.Visibility = Visibility.Visible;

            labelIngredientName.Visibility = Visibility.Hidden;
            ingNameInput.Visibility = Visibility.Hidden;

            labelIngredientQuantity.Visibility = Visibility.Hidden;
            ingQuantityInput.Visibility = Visibility.Hidden;

            labelIngredientUnit.Visibility = Visibility.Hidden;
            ingUnitInput.Visibility = Visibility.Hidden;

            labelIngredientCalories.Visibility = Visibility.Hidden;
            calInput.Visibility = Visibility.Hidden;

            labelIngredientFood.Visibility = Visibility.Hidden;
            foodGroup.Visibility = Visibility.Hidden;

            displaying.Visibility = Visibility.Hidden;
            scaling.Visibility = Visibility.Hidden;
            resetting.Visibility = Visibility.Hidden;
            clearing.Visibility = Visibility.Hidden;

            displayFilter.Visibility = Visibility.Hidden;

            labelTopIngredient.Visibility = Visibility.Hidden;

        }

        //Save button to save the ingredient details
        private void saveRecipeButton_Click(object sender, RoutedEventArgs e)
        {

            labelIngredientNumber.Visibility = Visibility.Hidden;
            ingInput.Visibility = Visibility.Hidden;

            labelRecipeName.Visibility = Visibility.Hidden;
            recipeInput.Visibility = Visibility.Hidden;

            displaying.Visibility = Visibility.Hidden;
            scaling.Visibility = Visibility.Hidden;
            resetting.Visibility = Visibility.Hidden;
            clearing.Visibility = Visibility.Hidden;
            //captureDetails.Visibility = Visibility.Hidden;
            displayFilter.Visibility = Visibility.Hidden;

            //store text box entries
            string recipe = recipeInput.Text;
            string ing = ingInput.Text;

            string ingName = ingNameInput.Text;
            string ingQuantity = ingQuantityInput.Text;
            string ingUnit = ingUnitInput.Text;
            string cal = calInput.Text;
            string food = foodGroup.Text;

            //if statement
            if (recipe != "" && ing != "")
            {
                recipeName.Add(recipe);
                ingredientsNumber.Add(ing);

                labelIngredientName.Visibility = Visibility.Visible;
                ingNameInput.Visibility = Visibility.Visible;

                labelIngredientQuantity.Visibility = Visibility.Visible;
                ingQuantityInput.Visibility = Visibility.Visible;

                labelIngredientUnit.Visibility = Visibility.Visible;
                ingUnitInput.Visibility = Visibility.Visible;

                labelIngredientCalories.Visibility = Visibility.Visible;
                calInput.Visibility = Visibility.Visible;

                labelIngredientFood.Visibility = Visibility.Visible;
                foodGroup.Visibility = Visibility.Visible;

                labelTopIngredient.Visibility = Visibility.Visible;

            }

            //if statement
            if (ingName != "" && ingQuantity != "" && ingUnit != "" && cal != "")
            {

                //label increment
                ingAccumulate += 1;
                labelTopIngredient.Content = $"Ingredient {ingAccumulate} ";

                ingredientName.Add(ingName + recipe);

                ingredientQuantity.Add(ingQuantity + recipe);

                firstIngredientQuantity.Add(ingQuantity + recipe);

                ingredientUnit.Add(ingUnit + recipe);

                ingredientCalories.Add(cal + recipe);

                ingredientFoodGroup.Add(food + recipe);
            }

            //Clearing the textbox
            ingInput.Clear();
            ingNameInput.Clear();
            ingQuantityInput.Clear();
            ingUnitInput.Clear();
            calInput.Clear();
            foodGroup.Text = string.Empty;
        }

        // Button click for the appearance of number of steps
        private void captureStepsButton_Click(object sender, RoutedEventArgs e)
        {
            captureDetails.Visibility = Visibility.Hidden;
            captureStepDetails.Visibility = Visibility.Visible;
            labelStepNumber.Visibility = Visibility.Visible;
            steInput.Visibility = Visibility.Visible;
            labelStepDescription.Visibility = Visibility.Hidden;
            steNameInput.Visibility = Visibility.Hidden;
            displayFilter.Visibility = Visibility.Hidden;
        }

        //Save the step number
        private void saveStepsButton_Click(object sender, RoutedEventArgs e)
        {

            labelStepDescription.Visibility = Visibility.Visible;
            steNameInput.Visibility = Visibility.Visible;

            labelStepNumber.Visibility = Visibility.Hidden;
            steInput.Visibility = Visibility.Hidden;
            displayFilter.Visibility = Visibility.Hidden;

            //store step details
            string ste = steInput.Text;
            string steName = steNameInput.Text;
            if (ste != "")
            {
                stepsNumber.Add(ste);

            }

            string recipe = recipeInput.Text;

            if (steName != "")
            {
                stepDescription.Add(steName + recipe);

            }


            steInput.Clear();
            steNameInput.Clear();

        }

        // Page will be clear
        private void doneStepButton_Click(object sender, RoutedEventArgs e)
        {

            labelIngredientName.Visibility = Visibility.Hidden;
            ingNameInput.Visibility = Visibility.Hidden;
            captureDetails.Visibility = Visibility.Hidden;
            captureStepDetails.Visibility = Visibility.Hidden;
            displayFilter.Visibility = Visibility.Hidden;

        }

        // Display
        private void displayButton_Click(object sender, RoutedEventArgs e)
        {
            clearing.Visibility = Visibility.Hidden;

            captureDetails.Visibility = Visibility.Hidden;
            scaling.Visibility = Visibility.Hidden;
            resetting.Visibility = Visibility.Hidden;
            clearing.Visibility = Visibility.Hidden;
            displaying.Visibility = Visibility.Visible;
            displayFilter.Visibility = Visibility.Hidden;

            //method that sort the recipe names
            recipeName.Sort();


            foreach (string name in MainWindow.recipeName)
            {
                recipeList.Items.Add(name);
            }


        }
        private void viewFilterDisplayButton_Click(object sender, RoutedEventArgs e)
        {
            displayFilter.Visibility = Visibility.Visible;
            displaying.Visibility = Visibility.Hidden;

            string food = foodGroup.Text;

            //initialising 
            int one = 0;
            int two = 0;
            int three = 0;
            int four = 0;
            int five = 0;
            int six = 0;
            int seven = 0;

            //for loop
            for (int u = 0; u < ingredientFilterFoodGroup.Count; u++)
            {


                if (ingredientFilterFoodGroup[u].Equals("Starchy foods"))
                {
                    one += 1;
                }
                else if (ingredientFilterFoodGroup[u].Equals("Vegetables and fruits"))
                {
                    two += 1;
                }
                else if (ingredientFilterFoodGroup[u].Equals("Dry beans, peas, lentils and soya"))
                {
                    three += 1;
                }
                else if (ingredientFilterFoodGroup[u].Equals("Chicken, fish, meat and eggs"))
                {
                    four += 1;
                }
                else if (ingredientFilterFoodGroup[u].Equals("Milk and dairy products"))
                {
                    five += 1;
                }
                else if (ingredientFilterFoodGroup[u].Equals("Fats and oil"))
                {
                    six += 1;
                }
                else if (ingredientFilterFoodGroup[u].Equals("Water"))
                {
                    seven += 1;
                }

            }

            SeriesCollection = new SeriesCollection
            {


                new PieSeries
                {

                    Title = "Starchy foods",
                    Values = new ChartValues<ObservableValue> { new ObservableValue(one) },
                    DataLabels = true
                },
                  new PieSeries
                {

                    Title = "Vegetables and fruits",
                    Values = new ChartValues<ObservableValue> { new ObservableValue(two) },
                    DataLabels = true
                },
                    new PieSeries
                {

                    Title = "Dry beans, peas, lentils and soya",
                    Values = new ChartValues<ObservableValue> { new ObservableValue(three) },
                    DataLabels = true
                },
                      new PieSeries
                {

                    Title = "Chicken, fish, meat and eggs",
                    Values = new ChartValues<ObservableValue> { new ObservableValue(four)},

                    DataLabels = true
                },
                      new PieSeries
                      {
                          Title = "Milk and dairy products",
                         Values = new ChartValues<ObservableValue> { new ObservableValue(five)},

                    DataLabels = true
                      },

                        new PieSeries
                      {
                          Title = "Fats and oil",
                         Values = new ChartValues<ObservableValue> { new ObservableValue(six)},

                    DataLabels = true
                      },
                          new PieSeries
                      {
                          Title = "Water",
                         Values = new ChartValues<ObservableValue> { new ObservableValue(seven)},

                    DataLabels = true
                      },




            };

            DataContext = this;
        }
        private void addFilterDisplayButton_Click(object sender, RoutedEventArgs e)
        {
            displayFilter.Visibility = Visibility.Hidden;
            if (recipeList.Text != "")
            {
                string oneRecipe = recipeList.Text;
                for (int y = 0; y < ingredientName.Count; y++)
                {
                    if (ingredientFoodGroup[y].Contains(oneRecipe))
                    {
                        ingredientFilterFoodGroup.Add(ingredientFoodGroup[y].Replace(oneRecipe, ""));


                    }

                }
            }
            else
            {
                //message box error handling
                MessageBox.Show("choose recipes to add");
            }

        }
        private void returnToDisplaButton_Click(object sender, RoutedEventArgs e)
        {
            displaying.Visibility = Visibility.Visible;
            displayFilter.Visibility = Visibility.Hidden;

            ingredientFilterFoodGroup.Clear();
            DataContext = null;

        }
        private void saveRecipeOnDisplayButton_Click(object sender, RoutedEventArgs e)
        {
            displayFilter.Visibility = Visibility.Hidden;
            captureStepDetails.Visibility = Visibility.Hidden;

            // string recipe = recipeInput.Text;

            string ingName = ingNameInput.Text;
            string ingQuantity = ingQuantityInput.Text;
            string ingUnit = ingUnitInput.Text;
            string cal = calInput.Text;
            string food = foodGroup.Text;

            string steName = steNameInput.Text;


            string oneRecipe = recipeList.Text;

            for (int z = 0; z < recipeName.Count; z++)
            {
                if (recipeName[z].Contains(oneRecipe))
                {
                    //display
                    displayRecipeList.Items.Add("\n" + oneRecipe + "\n");
                }
            }

            for (int y = 0; y < ingredientName.Count; y++)
            {
                if (ingredientName[y].Contains(oneRecipe) && ingredientQuantity[y].Contains(oneRecipe) && ingredientUnit[y].Contains(oneRecipe) && ingredientCalories[y].Contains(oneRecipe) && ingredientFoodGroup[y].Contains(oneRecipe))
                {
                    //display
                    displayRecipeList.Items.Add("Ingredient: " + ingredientQuantity[y].Replace(oneRecipe, "") + " " + ingredientUnit[y].Replace(oneRecipe, "") + " of " + ingredientName[y].Replace(oneRecipe, ""));
                    displayRecipeList.Items.Add("Ingredient Calories: " + ingredientCalories[y].Replace(oneRecipe, ""));
                    displayRecipeList.Items.Add("Ingredient Food Group: " + ingredientFoodGroup[y].Replace(oneRecipe, "") + "\n");

                }

            }
            recipeList.Items.Clear();

            stepDescription.Add(steName);

            for (int g = 0; g < stepDescription.Count; g++)
            {
                if (stepDescription[g].Contains(oneRecipe))
                {
                    //display
                    displayRecipeList.Items.Add("\n" + "Step: " + stepDescription[g].Replace(oneRecipe, ""));
                }
            }

        }


        private void doneDisplayButton_Click(object sender, RoutedEventArgs e)
        {
            displaying.Visibility = Visibility.Hidden;
        }

        // Scaling
        private void scaleButton_Click(object sender, RoutedEventArgs e)
        {
            captureDetails.Visibility = Visibility.Hidden;

            captureStepDetails.Visibility = Visibility.Hidden;
            displaying.Visibility = Visibility.Hidden;

            resetting.Visibility = Visibility.Hidden;
            clearing.Visibility = Visibility.Hidden;
            scaling.Visibility = Visibility.Visible;

            //method that sort the recipe names
            recipeName.Sort();


            foreach (string name in MainWindow.recipeName)
            {
                ScaleRecipeList.Items.Add(name);
            }

        }

        private void saveScaleButton_Click(object sender, RoutedEventArgs e)
        {
            string sce = ScaleRecipeList.Text;
            string scale = scaleFactor.Text;

            if (scale == "0.5(Half)")
            {

                for (int c = 0; c < ingredientName.Count; c++)
                {
                    if (ingredientName[c].Contains(sce))
                    {
                        double mult = Convert.ToDouble(ingredientQuantity[c].Replace(sce, ""));

                        double sum = mult * 1 / 2;
                        ingredientQuantity[c] = "" + sum + sce;
                    }
                }
            }
            else if (scale == "2(Double)")
            {

                for (int d = 0; d < ingredientName.Count; d++)
                {
                    if (ingredientName[d].Contains(sce))
                    {

                        double mult = Convert.ToDouble(ingredientQuantity[d].Replace(sce, ""));

                        double sum = mult * 2;
                        ingredientQuantity[d] = "" + sum + sce;
                    }
                }
            }
            else if (scale.Equals("3(Triple)"))
            {

                for (int d = 0; d < ingredientName.Count; d++)
                {
                    if (ingredientName[d].Contains(sce))
                    {

                        double mult = Convert.ToDouble(ingredientQuantity[d].Replace(sce, ""));

                        double sum = mult * 3;
                        ingredientQuantity[d] = "" + sum + sce;
                    }
                }
            }
            ScaleRecipeList.Items.Clear();
            scaleFactor.Text = string.Empty;
        }

        private void doneScaleButton_Click(object sender, RoutedEventArgs e)
        {
            scaling.Visibility = Visibility.Hidden;
        }

        // reset
        private void resetButton_Click(object sender, RoutedEventArgs e)
        {
            resetting.Visibility = Visibility.Visible;
            scaling.Visibility = Visibility.Hidden;
            captureDetails.Visibility = Visibility.Hidden;
            displaying.Visibility = Visibility.Hidden;
            captureStepDetails.Visibility = Visibility.Hidden;



            clearing.Visibility = Visibility.Hidden;

            //method that sort the recipe names
            recipeName.Sort();

            foreach (string name in MainWindow.recipeName)
            {
                ResetRecipeList.Items.Add(name);
            }
        }
        private void saveResetButton_Click(object sender, RoutedEventArgs e)
        {
            string reset = ResetRecipeList.Text;

            for (int f = 0; f < ingredientName.Count; f++)
            {
                if (reset != "")
                {

                    ingredientQuantity[f] = firstIngredientQuantity[f];
                }
            }
            ResetRecipeList.Items.Clear();
            // ResetRecipeList.Clear();
        }

        private void doneResetButton_Click(object sender, RoutedEventArgs e)
        {
            resetting.Visibility = Visibility.Hidden;
        }

        //clear
        private void clearButton_Click(object sender, RoutedEventArgs e)
        {
            clearing.Visibility = Visibility.Visible;
            resetting.Visibility = Visibility.Hidden;
            scaling.Visibility = Visibility.Hidden;
            // captureDetails.Visibility = Visibility.Hidden;
            displaying.Visibility = Visibility.Hidden;


            //method that sort the recipe names
            recipeName.Sort();

            foreach (string name in MainWindow.recipeName)
            {
                ClearRecipeList.Items.Add(name);
            }

        }
        private void clearrButton_Click(object sender, RoutedEventArgs e)
        {
            string clear = ClearRecipeList.Text;
            //recipeName = new List<string> ();
            recipeName.Remove(clear);
            foreach (string name in recipeName)
            {
                ClearRecipeList.Items.Add(name);
            }
            //recipeClearList.Items.Clear();
            //oneClearRecipeInput.Clear();
        }
        private void doneClearButton_Click(object sender, RoutedEventArgs e)
        {
            clearing.Visibility = Visibility.Hidden;
        }
        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            Close(); //End of the application use
        }
    }
}
